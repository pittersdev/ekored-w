<?php
$type = 'template';
include( dirname( __FILE__ ) . '/new-form-overlay.php' );
?>

<div id="frm_preview_template_modal" class="frm_hidden settings-lite-cta">
	<div class="metabox-holder">
		<div class="postbox">
			<div class="inside" id="frm-preview-block">
			</div>
		</div>
	</div>
</div>

